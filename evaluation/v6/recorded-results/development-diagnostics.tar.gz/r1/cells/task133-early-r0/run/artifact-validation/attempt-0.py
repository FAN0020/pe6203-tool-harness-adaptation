"""Safe arithmetic expression evaluator.

Security model (defense in depth):
  1. Type and length checks on the raw input (max 1000 characters).
  2. Parsing via ``ast.parse`` in ``eval`` mode -- the source is *never*
     executed, only inspected as a syntax tree.
  3. A strict allowlist walk over the AST: only numeric literals,
     parentheses (implicit in the tree), unary +/- and binary + - * / are
     accepted.  Every other node type fails closed.
  4. A node-count / depth budget to bound work on adversarial input.
  5. Evaluation by a hand-written recursive interpreter over the validated
     tree -- no ``eval``, ``exec``, ``compile``, ``__import__``, attribute
     access, subscripting, calls, names or string literals anywhere.

Public API:
    safe_eval(expression) -> int | float

Raises:
    TypeError   -- input is not a ``str``
    ValueError  -- empty/oversized input, unsupported syntax, division by
                   zero, or a non-finite result
    SyntaxError -- the text is not a well-formed Python expression
"""

from __future__ import annotations

import ast
import math
import operator
from typing import Union

__all__ = ["safe_eval", "MAX_EXPRESSION_LENGTH", "MAX_NODES", "MAX_DEPTH"]

Number = Union[int, float]

MAX_EXPRESSION_LENGTH = 1000
MAX_NODES = 200
MAX_DEPTH = 50

_BIN_OPS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
}

_UNARY_OPS = {
    ast.UAdd: operator.pos,
    ast.USub: operator.neg,
}


def _check_input(expression: object) -> str:
    """Validate the raw input before it ever reaches the parser."""
    if not isinstance(expression, str):
        raise TypeError(
            "expression must be a str, got %s" % type(expression).__name__
        )
    if not expression.strip():
        raise ValueError("expression must not be empty")
    if len(expression) > MAX_EXPRESSION_LENGTH:
        raise ValueError(
            "expression exceeds the maximum length of %d characters"
            % MAX_EXPRESSION_LENGTH
        )
    # Reject NUL and other control characters outright.
    for ch in expression:
        if ch != "\t" and ch != "\n" and ch != "\r" and ord(ch) < 32:
            raise ValueError("expression contains a disallowed control character")
    return expression


def _parse(expression: str) -> ast.Expression:
    """Parse to an AST without executing anything."""
    try:
        tree = ast.parse(expression, mode="eval")
    except SyntaxError:
        raise
    except (ValueError, MemoryError, RecursionError) as exc:
        raise ValueError("expression could not be parsed: %s" % exc) from None
    if not isinstance(tree, ast.Expression):
        raise ValueError("expression must be a single expression")
    return tree


def _validate(node: ast.AST, depth: int, counter: list) -> None:
    """Walk the tree and fail closed on anything outside the allowlist."""
    counter[0] += 1
    if counter[0] > MAX_NODES:
        raise ValueError("expression is too complex (node budget exceeded)")
    if depth > MAX_DEPTH:
        raise ValueError("expression is nested too deeply")

    if isinstance(node, ast.Expression):
        _validate(node.body, depth + 1, counter)
        return

    if isinstance(node, ast.Constant):
        value = node.value
        # bool is a subclass of int -- reject it explicitly.
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError(
                "only numeric literals are allowed, got %r" % (value,)
            )
        if isinstance(value, float) and not math.isfinite(value):
            raise ValueError("non-finite numeric literal is not allowed")
        return

    if isinstance(node, ast.BinOp):
        if type(node.op) not in _BIN_OPS:
            raise ValueError(
                "operator %s is not allowed" % type(node.op).__name__
            )
        _validate(node.left, depth + 1, counter)
        _validate(node.right, depth + 1, counter)
        return

    if isinstance(node, ast.UnaryOp):
        if type(node.op) not in _UNARY_OPS:
            raise ValueError(
                "unary operator %s is not allowed" % type(node.op).__name__
            )
        _validate(node.operand, depth + 1, counter)
        return

    # Everything else (Name, Call, Attribute, Subscript, Lambda, Compare,
    # BoolOp, IfExp, comprehensions, JoinedStr, Starred, ...) is rejected.
    raise ValueError(
        "unsupported syntax: %s is not allowed" % type(node).__name__
    )


def _eval(node: ast.AST) -> Number:
    """Interpret a pre-validated tree.  No dynamic code execution."""
    if isinstance(node, ast.Expression):
        return _eval(node.body)

    if isinstance(node, ast.Constant):
        return node.value  # already validated as a finite int/float

    if isinstance(node, ast.BinOp):
        left = _eval(node.left)
        right = _eval(node.right)
        op = _BIN_OPS[type(node.op)]
        if op is operator.truediv and right == 0:
            raise ValueError("division by zero")
        try:
            result = op(left, right)
        except ZeroDivisionError:
            raise ValueError("division by zero") from None
        except OverflowError:
            raise ValueError("numeric overflow") from None
        return result

    if isinstance(node, ast.UnaryOp):
        return _UNARY_OPS[type(node.op)](_eval(node.operand))

    # Unreachable after validation; kept as a fail-closed guard.
    raise ValueError("unsupported syntax: %s" % type(node).__name__)


def safe_eval(expression: str) -> Number:
    """Safely evaluate an arithmetic expression.

    Supports numeric literals (int/float, including exponent notation),
    parentheses, unary +/- and binary + - * /.

    >>> safe_eval("2 + 3 * (4 - 1) / 2")
    6.5
    >>> safe_eval("-(-3) + 4")
    7
    """
    text = _check_input(expression)
    tree = _parse(text)
    _validate(tree, 0, [0])
    result = _eval(tree)

    if isinstance(result, bool) or not isinstance(result, (int, float)):
        raise ValueError("expression did not produce a number")
    if isinstance(result, float) and not math.isfinite(result):
        raise ValueError("result is not a finite number")
    return result


if __name__ == "__main__":  # pragma: no cover - manual smoke test
    import sys

    for arg in sys.argv[1:] or ["2 + 3 * (4 - 1) / 2"]:
        try:
            print("%s = %r" % (arg, safe_eval(arg)))
        except (ValueError, TypeError, SyntaxError) as exc:
            print("%s -> %s: %s" % (arg, type(exc).__name__, exc))
