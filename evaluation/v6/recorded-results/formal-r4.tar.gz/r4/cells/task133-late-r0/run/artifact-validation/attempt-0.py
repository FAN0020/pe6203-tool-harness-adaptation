"""Safe arithmetic expression evaluator.

Public interface:
    safe_eval(expression) -> int | float

Accepts strings of at most 1000 characters containing only:
    * numeric literals (int, float, exponent notation)
    * parentheses
    * unary + and -
    * binary +, -, *, /

Rejects everything else (identifiers, attribute access, calls, strings,
comprehensions, lambdas, imports, ...) by raising ValueError, TypeError or
SyntaxError.  No use of eval()/exec()/compile() on untrusted input.

Security notes (OWASP-aligned):
    * A01 Broken Access Control / A03 Injection: never pass user input to
      eval/exec; use an allow-list AST walker (this module).
    * A04 Insecure Design: enforce input length, node-count and nesting
      limits so the parser cannot be used for resource exhaustion.
    * A05 Security Misconfiguration: no globals/builtins are exposed; the
      evaluator has no ambient authority.
    * A08 Software & Data Integrity: deterministic, dependency-free logic.
    * A09 Logging/Monitoring: callers should log rejected inputs (without
      echoing secrets) and alert on repeated failures.
"""

from __future__ import annotations

import ast
import math
import operator
from typing import Union

__all__ = ["safe_eval", "MAX_EXPRESSION_LENGTH", "MAX_NODES", "MAX_DEPTH"]

Number = Union[int, float]

MAX_EXPRESSION_LENGTH = 1000
MAX_NODES = 200
MAX_DEPTH = 50

_BIN_OPS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
}

_UNARY_OPS = {
    ast.UAdd: operator.pos,
    ast.USub: operator.neg,
}


def _check_limits(tree: ast.AST) -> None:
    """Reject trees that are too large or too deeply nested."""
    nodes = 0
    stack = [(tree, 0)]
    while stack:
        node, depth = stack.pop()
        nodes += 1
        if nodes > MAX_NODES:
            raise ValueError("expression is too complex")
        if depth > MAX_DEPTH:
            raise ValueError("expression is nested too deeply")
        for child in ast.iter_child_nodes(node):
            stack.append((child, depth + 1))


def _eval_node(node: ast.AST) -> Number:
    if isinstance(node, ast.Expression):
        return _eval_node(node.body)

    if isinstance(node, ast.Constant):
        value = node.value
        # bool is a subclass of int; reject it explicitly.
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("only numeric literals are allowed")
        if isinstance(value, float) and not math.isfinite(value):
            raise ValueError("non-finite numeric literal is not allowed")
        return value

    if isinstance(node, ast.UnaryOp):
        op = _UNARY_OPS.get(type(node.op))
        if op is None:
            raise ValueError("unsupported unary operator")
        return op(_eval_node(node.operand))

    if isinstance(node, ast.BinOp):
        op = _BIN_OPS.get(type(node.op))
        if op is None:
            raise ValueError("unsupported binary operator")
        left = _eval_node(node.left)
        right = _eval_node(node.right)
        try:
            result = op(left, right)
        except ZeroDivisionError:
            raise ValueError("division by zero") from None
        except OverflowError:
            raise ValueError("numeric overflow") from None
        if isinstance(result, float) and not math.isfinite(result):
            raise ValueError("result is not finite")
        return result

    raise ValueError(f"unsupported expression element: {type(node).__name__}")


def safe_eval(expression: str) -> Number:
    """Evaluate a restricted arithmetic expression.

    Args:
        expression: string of at most 1000 characters.

    Returns:
        int or float result.

    Raises:
        TypeError: if ``expression`` is not a str.
        ValueError: if the expression is empty, too long, too complex, uses
            unsupported syntax/operators, divides by zero, or produces a
            non-finite result.
        SyntaxError: if the expression cannot be parsed.
    """
    if not isinstance(expression, str):
        raise TypeError("expression must be a string")
    if len(expression) > MAX_EXPRESSION_LENGTH:
        raise ValueError(
            f"expression exceeds {MAX_EXPRESSION_LENGTH} characters"
        )
    if not expression.strip():
        raise ValueError("expression is empty")

    # ast.parse raises SyntaxError for malformed input; mode='eval' forbids
    # statements, and the walker below forbids everything but arithmetic.
    tree = ast.parse(expression, mode="eval")
    _check_limits(tree)
    return _eval_node(tree)


if __name__ == "__main__":  # pragma: no cover - manual smoke test
    import sys

    for arg in sys.argv[1:] or ["(8 + 4) / 3"]:
        try:
            print(f"{arg} = {safe_eval(arg)}")
        except (ValueError, TypeError, SyntaxError) as exc:
            print(f"{arg!r}: rejected ({type(exc).__name__}: {exc})")
