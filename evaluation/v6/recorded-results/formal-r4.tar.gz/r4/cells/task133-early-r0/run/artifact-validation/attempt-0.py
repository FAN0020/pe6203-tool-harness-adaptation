"""Safe arithmetic expression evaluator.

Public API:
    safe_eval(expression) -> int | float

Contract:
    * Accepts a ``str`` of at most 1000 characters.
    * Supports numeric literals (int/float, incl. exponent notation), parentheses,
      unary +/- and the binary operators +, -, *, /.
    * Returns a numeric result (int or float).
    * Raises TypeError for non-string input, ValueError for unsupported or
      invalid input (identifiers, calls, attributes, strings, division by zero,
      oversized/deeply nested input), and SyntaxError for unparsable text.

Security model (defense in depth):
    1. No eval/exec/compile of untrusted text -- only ``ast.parse`` in 'eval' mode.
    2. Strict AST node whitelist; every other node type is rejected.
    3. Literal values are restricted to real numbers (no str/bytes/bool/complex).
    4. Input length, AST depth and node-count caps to bound work (DoS resistance).
    5. Evaluation is a hand-written recursive walk over the validated tree, so no
       Python object protocol (__add__, __mul__, ...) of attacker-chosen objects
       is ever invoked.
    6. Division by zero is reported as ValueError instead of leaking a
       ZeroDivisionError with internal detail.

This module is intentionally dependency-free and side-effect free.
"""

from __future__ import annotations

import ast
import math
import numbers
from typing import Union

__all__ = ["safe_eval", "MAX_EXPRESSION_LENGTH", "MAX_DEPTH", "MAX_NODES"]

Number = Union[int, float]

# --- Hard limits (resource-exhaustion guards) -------------------------------
MAX_EXPRESSION_LENGTH = 1000
MAX_DEPTH = 50
MAX_NODES = 500

# --- Whitelists -------------------------------------------------------------
_ALLOWED_NODES = (
    ast.Expression,
    ast.BinOp,
    ast.UnaryOp,
    ast.Constant,
    ast.Add,
    ast.Sub,
    ast.Mult,
    ast.Div,
    ast.UAdd,
    ast.USub,
)

_BIN_OPS = {
    ast.Add: lambda a, b: a + b,
    ast.Sub: lambda a, b: a - b,
    ast.Mult: lambda a, b: a * b,
    ast.Div: lambda a, b: a / b,
}

_UNARY_OPS = {
    ast.UAdd: lambda a: +a,
    ast.USub: lambda a: -a,
}


def _is_number(value: object) -> bool:
    """True only for real int/float literals (bool and complex excluded)."""
    if isinstance(value, bool):
        return False
    if isinstance(value, int):
        return True
    if isinstance(value, float):
        return math.isfinite(value)
    return False


def _check_tree(tree: ast.AST) -> None:
    """Validate the whole tree against the whitelist, depth and size caps."""
    node_count = 0
    # Iterative DFS with explicit depth tracking: avoids recursion limits on
    # hostile input and lets us enforce MAX_DEPTH deterministically.
    stack = [(tree, 0)]
    while stack:
        node, depth = stack.pop()
        node_count += 1
        if node_count > MAX_NODES:
            raise ValueError("expression is too complex")
        if depth > MAX_DEPTH:
            raise ValueError("expression is nested too deeply")
        if not isinstance(node, _ALLOWED_NODES):
            raise ValueError(
                "unsupported syntax: %s" % type(node).__name__
            )
        if isinstance(node, ast.Constant) and not _is_number(node.value):
            raise ValueError("only numeric literals are allowed")
        for child in ast.iter_child_nodes(node):
            stack.append((child, depth + 1))


def _eval_node(node: ast.AST) -> Number:
    """Evaluate a pre-validated node. Only whitelisted shapes can appear."""
    if isinstance(node, ast.Expression):
        return _eval_node(node.body)
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, ast.UnaryOp):
        operand = _eval_node(node.operand)
        return _UNARY_OPS[type(node.op)](operand)
    if isinstance(node, ast.BinOp):
        left = _eval_node(node.left)
        right = _eval_node(node.right)
        if isinstance(node.op, ast.Div) and right == 0:
            raise ValueError("division by zero")
        return _BIN_OPS[type(node.op)](left, right)
    # Unreachable after _check_tree, kept as a fail-closed guard.
    raise ValueError("unsupported syntax: %s" % type(node).__name__)


def safe_eval(expression: str) -> Number:
    """Evaluate a restricted arithmetic expression safely.

    Args:
        expression: arithmetic text, e.g. ``"2 + 3 * (4 - 1)"``.

    Returns:
        int or float result.

    Raises:
        TypeError: ``expression`` is not a ``str``.
        ValueError: unsupported constructs, non-finite/oversized input,
            division by zero, or a non-numeric result.
        SyntaxError: the text is not a valid Python expression.
    """
    if not isinstance(expression, str):
        raise TypeError("expression must be a str")
    if len(expression) > MAX_EXPRESSION_LENGTH:
        raise ValueError(
            "expression exceeds %d characters" % MAX_EXPRESSION_LENGTH
        )
    if not expression.strip():
        raise ValueError("expression is empty")

    # ast.parse raises SyntaxError for malformed text; that is part of the
    # public contract and is deliberately propagated.
    tree = ast.parse(expression, mode="eval")

    _check_tree(tree)
    result = _eval_node(tree)

    if not isinstance(result, numbers.Real) or isinstance(result, bool):
        raise ValueError("expression did not produce a number")
    if isinstance(result, float) and not math.isfinite(result):
        raise ValueError("result is not finite")
    return result


if __name__ == "__main__":  # pragma: no cover - tiny manual smoke test
    for sample in ("2 + 3 * (4 - 1)", "-(1.5e2) / 4", "1/0", "__import__('os')"):
        try:
            print(sample, "=>", safe_eval(sample))
        except (ValueError, TypeError, SyntaxError) as exc:
            print(sample, "=>", type(exc).__name__, exc)
