"""Safe arithmetic expression evaluator.

Public API:
    safe_eval(expression) -> int | float

Contract:
    * Accepts a string of at most 1000 characters.
    * Supports numeric literals (int, float, exponent notation), parentheses,
      unary +/- and binary +, -, *, /.
    * Returns a numeric result (int or float).
    * Raises ValueError for unsupported/invalid constructs (identifiers,
      attribute access, strings, calls, imports, division by zero, etc.).
    * Raises TypeError for non-string input.
    * Raises SyntaxError for malformed syntax.

Security design (OWASP-aligned):
    * No eval/exec/compile/ast.literal_eval on untrusted input.
    * Whitelist grammar: a hand-written recursive-descent parser accepts only
      the tokens it explicitly knows; everything else is rejected.
    * No name resolution, no attribute access, no subscripting, no calls, no
      string literals, no comprehensions, no lambdas, no f-strings.
    * Bounded input length and bounded nesting depth (defense in depth against
      resource-exhaustion / stack-exhaustion abuse).
    * Errors are generic and do not leak internals.
"""

from __future__ import annotations

import math
import re
from typing import List, Tuple, Union

__all__ = ["safe_eval", "MAX_EXPRESSION_LENGTH", "MAX_DEPTH"]

Number = Union[int, float]

MAX_EXPRESSION_LENGTH = 1000
MAX_DEPTH = 100

# Token kinds
_NUMBER = "NUMBER"
_PLUS = "PLUS"
_MINUS = "MINUS"
_STAR = "STAR"
_SLASH = "SLASH"
_LPAREN = "LPAREN"
_RPAREN = "RPAREN"
_EOF = "EOF"

# Numeric literal: 12, 12.5, .5, 1e9, 1.5E-3 (no sign here; sign is unary op).
_NUMBER_RE = re.compile(r"(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?")

_SINGLE_CHAR_TOKENS = {
    "+": _PLUS,
    "-": _MINUS,
    "*": _STAR,
    "/": _SLASH,
    "(": _LPAREN,
    ")": _RPAREN,
}


class _Token:
    __slots__ = ("kind", "value", "pos")

    def __init__(self, kind: str, value: object, pos: int) -> None:
        self.kind = kind
        self.value = value
        self.pos = pos

    def __repr__(self) -> str:  # pragma: no cover - debugging aid only
        return f"_Token({self.kind!r}, {self.value!r}, {self.pos})"


def _tokenize(text: str) -> List[_Token]:
    """Convert text into a token list using a strict whitelist."""
    tokens: List[_Token] = []
    i = 0
    n = len(text)
    while i < n:
        ch = text[i]
        if ch in " \t\r\n\f\v":
            i += 1
            continue
        if ch in _SINGLE_CHAR_TOKENS:
            tokens.append(_Token(_SINGLE_CHAR_TOKENS[ch], ch, i))
            i += 1
            continue
        if ch.isdigit() or ch == ".":
            match = _NUMBER_RE.match(text, i)
            if match is None:
                raise ValueError(f"Invalid numeric literal at position {i}")
            literal = match.group(0)
            i = match.end()
            # Reject things like "1.2.3" or "1e" that the regex stops short of.
            if i < n and (text[i].isdigit() or text[i] == "."):
                raise ValueError(f"Invalid numeric literal at position {i}")
            try:
                if any(c in literal for c in ".eE"):
                    value: Number = float(literal)
                else:
                    value = int(literal)
            except (ValueError, OverflowError):
                raise ValueError(f"Invalid numeric literal at position {match.start()}")
            if isinstance(value, float) and not math.isfinite(value):
                raise ValueError(f"Numeric literal out of range at position {match.start()}")
            tokens.append(_Token(_NUMBER, value, match.start()))
            continue
        # Anything else (letters, quotes, brackets, commas, semicolons,
        # underscores, '@', ':', '\\', non-ASCII, ...) is unsupported.
        raise ValueError(f"Unsupported character {ch!r} at position {i}")
    tokens.append(_Token(_EOF, None, n))
    return tokens


class _Parser:
    """Recursive-descent parser that evaluates as it parses.

    Grammar (left-associative, standard precedence):
        expr    := term (('+' | '-') term)*
        term    := unary (('*' | '/') unary)*
        unary   := ('+' | '-') unary | primary
        primary := NUMBER | '(' expr ')'
    """

    __slots__ = ("_tokens", "_index", "_depth")

    def __init__(self, tokens: List[_Token]) -> None:
        self._tokens = tokens
        self._index = 0
        self._depth = 0

    def _peek(self) -> _Token:
        return self._tokens[self._index]

    def _advance(self) -> _Token:
        token = self._tokens[self._index]
        self._index += 1
        return token

    def _enter(self) -> None:
        self._depth += 1
        if self._depth > MAX_DEPTH:
            raise ValueError("Expression nesting too deep")

    def _leave(self) -> None:
        self._depth -= 1

    def parse(self) -> Number:
        result = self._expr()
        token = self._peek()
        if token.kind != _EOF:
            raise SyntaxError(f"Unexpected token {token.value!r} at position {token.pos}")
        return result

    def _expr(self) -> Number:
        self._enter()
        try:
            value = self._term()
            while True:
                kind = self._peek().kind
                if kind == _PLUS:
                    self._advance()
                    value = value + self._term()
                elif kind == _MINUS:
                    self._advance()
                    value = value - self._term()
                else:
                    return value
        finally:
            self._leave()

    def _term(self) -> Number:
        self._enter()
        try:
            value = self._unary()
            while True:
                kind = self._peek().kind
                if kind == _STAR:
                    self._advance()
                    value = value * self._unary()
                elif kind == _SLASH:
                    self._advance()
                    divisor = self._unary()
                    if divisor == 0:
                        raise ValueError("Division by zero")
                    value = value / divisor
                else:
                    return value
        finally:
            self._leave()

    def _unary(self) -> Number:
        self._enter()
        try:
            kind = self._peek().kind
            if kind == _PLUS:
                self._advance()
                return +self._unary()
            if kind == _MINUS:
                self._advance()
                return -self._unary()
            return self._primary()
        finally:
            self._leave()

    def _primary(self) -> Number:
        token = self._peek()
        if token.kind == _NUMBER:
            self._advance()
            return token.value  # type: ignore[return-value]
        if token.kind == _LPAREN:
            self._advance()
            value = self._expr()
            closing = self._peek()
            if closing.kind != _RPAREN:
                raise SyntaxError(f"Expected ')' at position {closing.pos}")
            self._advance()
            return value
        if token.kind == _EOF:
            raise SyntaxError("Unexpected end of expression")
        raise SyntaxError(f"Unexpected token {token.value!r} at position {token.pos}")


def safe_eval(expression: str) -> Number:
    """Safely evaluate a restricted arithmetic expression.

    Args:
        expression: A string of at most 1000 characters containing numeric
            literals, parentheses, unary +/- and binary +, -, *, /.

    Returns:
        int or float: the numeric result.

    Raises:
        TypeError: if ``expression`` is not a string.
        ValueError: if the expression is too long, contains unsupported
            characters/constructs, or performs division by zero.
        SyntaxError: if the expression is syntactically malformed.
    """
    if not isinstance(expression, str):
        raise TypeError("expression must be a string")
    if len(expression) > MAX_EXPRESSION_LENGTH:
        raise ValueError(
            f"Expression exceeds maximum length of {MAX_EXPRESSION_LENGTH} characters"
        )
    if not expression.strip():
        raise SyntaxError("Empty expression")

    tokens = _tokenize(expression)
    result = _Parser(tokens).parse()

    if isinstance(result, float) and not math.isfinite(result):
        raise ValueError("Result is not a finite number")
    return result


if __name__ == "__main__":  # pragma: no cover - manual smoke test
    for sample in ("1 + 2 * 3", "-(4 - 1) / 2", "2 ** 3", "__import__('os')"):
        try:
            print(f"{sample!r} -> {safe_eval(sample)!r}")
        except (ValueError, TypeError, SyntaxError) as exc:
            print(f"{sample!r} -> {type(exc).__name__}: {exc}")
