const fs = require('fs');
const root = '/Users/fanysmacpro/Developer/agents/pe6203-agent-harness-safety/results/raw/extensions/magicui-log-dashboard-v1/development/cells/cell-004/run/workspace';
for (const f of fs.readdirSync(root+'/logs')) {
  console.log('=====', f);
  console.log(fs.readFileSync(root+'/logs/'+f,'utf8'));
}
console.log('===== tmp.js');
console.log(fs.readFileSync(root+'/tmp.js','utf8'));
