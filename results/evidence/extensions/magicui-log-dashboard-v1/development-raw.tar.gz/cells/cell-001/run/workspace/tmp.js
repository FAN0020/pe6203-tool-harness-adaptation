const { execSync } = require('child_process');
const wd = '/Users/fanysmacpro/Developer/agents/pe6203-agent-harness-safety/results/raw/extensions/magicui-log-dashboard-v1/development/cells/cell-001/run/workspace';
console.log(execSync(`cat "${wd}/tmp.js"`, {encoding:'utf8'}));
for (const f of ['studio-engine-part-1.log','studio-engine-part-2.log','studio-engine-part-3.log','studio-engine-part-4.log']) {
  console.log('=====', f);
  console.log(execSync(`cat "${wd}/logs/${f}"`, {encoding:'utf8'}));
}
