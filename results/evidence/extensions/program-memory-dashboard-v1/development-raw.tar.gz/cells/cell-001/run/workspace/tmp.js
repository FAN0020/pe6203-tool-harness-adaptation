const fs=require('fs');
for(const f of fs.readdirSync('logs')){
  const lines=fs.readFileSync('logs/'+f,'utf8').split(/\r?\n/);
  console.log('==== '+f+' total lines '+lines.length);
  const headers=lines.filter(l=>/^\[/.test(l));
  const others=lines.filter(l=>l.trim()!=='' && !/^\[/.test(l));
  const weird=headers.filter(l=>!/^\[\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z\] \[(ERROR|WARN|INFO|DEBUG)\] \[[^\]]+\]/.test(l));
  console.log('headers',headers.length,'nonblank continuation',others.length,'weird headers',weird.length);
  console.log('weird:',weird);
  const dates=new Set(headers.map(h=>h.slice(1,11)));
  console.log('dates',[...dates].sort());
  const levels={}; headers.forEach(h=>{const m=h.match(/\] \[(\w+)\]/); const k=m?m[1]:'?'; levels[k]=(levels[k]||0)+1;});
  console.log('levels',levels);
  console.log('tail:',lines.slice(-6));
}
