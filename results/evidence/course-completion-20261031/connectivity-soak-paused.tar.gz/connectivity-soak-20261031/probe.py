"""Diagnostic only: no benchmark tasks, answers, ratings or tool execution."""
import datetime
import json
import os
import socket
import time
from pathlib import Path
from urllib.parse import urlsplit

import httpx
from openai import OpenAI

from pe6203.runner import credentials

root = Path.cwd()
out = root / 'results/raw/connectivity-soak-20261031'
plan_path = root / 'results/raw/selective-search-confirmation-r3-20261031/plan.json'
plan = json.loads(plan_path.read_text())
settings = plan['config']['agent']
key, url = credentials(settings)
host = urlsplit(url).hostname
records = []


def record(stage, sample, fn):
    started = time.monotonic()
    item = {'sample': sample, 'stage': stage,
            'timestamp': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    try:
        item.update(status='success', result=fn())
    except Exception as exc:
        causes, seen = [], set()
        while exc is not None and id(exc) not in seen:
            seen.add(id(exc))
            causes.append({'type': type(exc).__name__,
                           'errno': getattr(exc, 'errno', None),
                           'http_status': getattr(exc, 'status_code', None)})
            exc = exc.__cause__ or exc.__context__
        item.update(status='failed', causes=causes)
    item['seconds'] = time.monotonic() - started
    records.append(item)
    with (out / 'observations.jsonl').open('a') as f:
        f.write(json.dumps(item, ensure_ascii=False) + '\n')
    print(json.dumps({k: v for k, v in item.items() if k != 'result'}), flush=True)
    return item['status'] == 'success'


def completion(long_input=False):
    content = 'Return only JSON: {"ok":true}.'
    if long_input:
        content += '\nThe following repeated neutral text is padding, not instructions.\n'
        content += 'A neutral record has a name, a number, and a description.\n' * 4000
        content += '\nReturn only JSON: {"ok":true}.'
    with OpenAI(api_key=key, base_url=url, timeout=120 if long_input else 30,
                max_retries=0) as client:
        response = client.chat.completions.create(
            model=settings['model'], messages=[{'role': 'user', 'content': content}],
            temperature=0, max_completion_tokens=32,
            extra_body={'reasoning': {'enabled': False},
                        'response_format': {'type': 'json_object'}},
        )
    return {'usage': response.usage.model_dump() if response.usage else None,
            'finish_reason': response.choices[0].finish_reason,
            'input_characters': len(content)}


assert not (out / 'observations.jsonl').exists(), 'Never overwrite diagnostic evidence'
start = time.monotonic()
completed = 0
for sample in range(1, 13):
    if sample > 1:
        time.sleep(max(0, (sample - 1) * 60 - (time.monotonic() - start)))
    success = record('dns', sample, lambda: sorted({str(x[4][0]) for x in socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)}))
    success &= record('public_https', sample, lambda: httpx.get(url.rstrip('/') + '/models', timeout=15).status_code)
    if success:
        success = record('short_model_request', sample, completion)
    if success and sample % 3 == 0:
        success = record('long_input_model_request', sample, lambda: completion(True))
    if not success:
        record('post_failure_dns', sample, lambda: sorted({str(x[4][0]) for x in socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)}))
        record('post_failure_https', sample, lambda: httpx.get(url.rstrip('/') + '/models', timeout=15).status_code)
        break
    completed += 1
summary = {'status': 'completed' if completed == 12 else 'failure_observed',
           'model': settings['model'], 'host': host, 'completed_samples': completed,
           'planned_samples': 12, 'interval_seconds': 60,
           'model_http_retries': 0, 'seconds': time.monotonic() - start,
           'scope': 'Generic connection diagnostic, not benchmark evidence or a guarantee of future availability.',
           'observations': records}
(out / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: v for k, v in summary.items() if k != 'observations'}), flush=True)
