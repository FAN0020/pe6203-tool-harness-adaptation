---
theme: default
layout: cover
transition: slide-left
background: https://images.unsplash.com/photo-1502189562704-87e622a34c85?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=2100&q=80
---

# Synthetic cover
## Subtitle

Presented by Contract probe

---
layout: default
transition: slide-left
---

OLD_PAGE_CANARY_74B: preserved source entry