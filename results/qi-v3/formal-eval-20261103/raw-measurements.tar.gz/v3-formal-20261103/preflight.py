import asyncio, hashlib, json, subprocess, zipfile
from pathlib import Path
from pe6203.benchmark import source, load_task, write_json
from pe6203.transport import sessions, snapshot
ROOT=Path.cwd(); OUT=ROOT/'results/raw/v3-formal-20261103'; TASKS=(430,133,90,235)
async def main():
    lock, upstream=source(ROOT)
    report={'commit':lock['commit'],'dataset_revision':lock['dataset_revision'],'tasks':{},'runtime':{}}
    for tid in TASKS:
        task=load_task(upstream,tid)
        report['tasks'][str(tid)]={**task,'question_sha256':hashlib.sha256(task['question'].encode()).hexdigest()}
        for stage in lock['stages']:
            cell=OUT/'metadata'/str(tid)/stage
            if (cell/'catalog.json').exists(): continue
            cell.mkdir(parents=True,exist_ok=True)
            try:
                async with asyncio.timeout(100):
                    async with sessions(ROOT,stage,task['servers'],cell/'workspace',cell/'mcp.stderr.log',30) as clients:
                        catalog=await snapshot(clients,stage,lock['commit'])
                        write_json(cell/'catalog.json',catalog)
                        print(json.dumps({'task':tid,'stage':stage,'tools':len(catalog['tools']),'status':'catalog_ok'}),flush=True)
            except Exception as exc:
                write_json(cell/'preflight-error.json',{'error':type(exc).__name__,'detail':str(exc)})
                print(json.dumps({'task':tid,'stage':stage,'status':'failed','error':str(exc)}),flush=True)
                raise
    for stage,spec in lock['stages'].items():
        base=ROOT/'.cache/mcpevol'/spec['directory']
        archive=base.parent/spec['archive']
        if not archive.exists(): archive=base/spec['archive']
        matches=list((ROOT/'.cache/mcpevol').rglob(spec['archive'])) if not archive.exists() else [archive]
        if len(matches)!=1: raise ValueError(f'archive count {stage}: {len(matches)}')
        archive=matches[0]
        h=hashlib.sha256()
        with archive.open('rb') as stream:
            for chunk in iter(lambda:stream.read(8*1024*1024),b''):h.update(chunk)
        if h.hexdigest()!=spec['sha256']:raise ValueError(f'archive hash mismatch {stage}')
        report['runtime'][stage]={'archive_sha256':h.hexdigest(),'catalogs':{}}
        for tid in TASKS:
            catalog=json.loads((OUT/'metadata'/str(tid)/stage/'catalog.json').read_text())
            report['runtime'][stage]['catalogs'][str(tid)]={'tools':len(catalog['tools']),'catalog_sha256':hashlib.sha256((OUT/'metadata'/str(tid)/stage/'catalog.json').read_bytes()).hexdigest()}
    report['node_version']=subprocess.check_output(['node','--version'],text=True).strip()
    report['implementation_commit']=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
    report['status']='passed'
    write_json(OUT/'preflight.json',report)
asyncio.run(main())
